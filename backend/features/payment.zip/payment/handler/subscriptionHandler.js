// src/features/payment/handlers/subscriptionHandler.js
export const sendSubscriptionEmail = async (userId, artistId) => {
  // fetch user + artist, then send email
  console.log(`📩 Sending subscription email to user ${userId} for artist ${artistId}`);
};