// src/features/payment/handlers/purchaseHandler.js
export const updatePurchaseHistory = async (userId, itemId, itemType) => {
  // update DB purchase history
  console.log(`🛒 Updating purchase history: ${userId} bought ${itemType} ${itemId}`);
};